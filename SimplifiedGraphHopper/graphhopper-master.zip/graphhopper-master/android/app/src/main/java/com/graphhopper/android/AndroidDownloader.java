package com.graphhopper.android;

import com.graphhopper.util.Downloader;

public class AndroidDownloader extends Downloader {
    public AndroidDownloader() {
        super("GraphHopper Android");
    }
}
