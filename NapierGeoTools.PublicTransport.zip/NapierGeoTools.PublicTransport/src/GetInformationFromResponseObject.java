import General.Location;
import ResponseTfL.Journey;
import ResponseTfL.Leg;
import ResponseTfL.Response;
import ResponseTfL.Time;

//public class GetInformationFromResponseObject {
//
//	public static int getDurationInMinutes(Journey journey) {
//		return journey.getDuration();
//	}
//
//	public static Location getDeparturePoint(Journey journey) {
//		if (journey.getLegs()[0].getDeparturePoint() != null)
//			return journey.getLegs()[0].getDeparturePoint();
//		return null;
//	}
//
//	public static Location getArrivalPoint(Journey journey) {
//		if (journey.getLegs()[journey.getLegs().length - 1].getArrivalPoint() != null)
//			return journey.getLegs()[journey.getLegs().length - 1].getArrivalPoint();
//		return null;
//
//	}
//
//	public static String getDepartureTime(Journey journey) {
//		if (journey.getLegs()[0].getDepartureTime() != null)
//			return journey.getLegs()[0].getDepartureTime();
//		return null;
//	}
//
//	public static String getArrivalTime(Journey journey) {
//		if (journey.getLegs()[journey.getLegs().length - 1].getArrivalTime() != null)
//			return journey.getLegs()[journey.getLegs().length - 1].getArrivalTime();
//		return null;
//
//	}
//}
