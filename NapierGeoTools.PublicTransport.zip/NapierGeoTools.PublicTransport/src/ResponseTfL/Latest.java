package ResponseTfL;
//package Response;
//
//public  class Latest {
//    public  String date;
//    public  String time;
//    public  String timeIs;
//    public  String uri;
//
//    public Latest(String date, String time, String timeIs, String uri){
//        this.date = date;
//        this.time = time;
//        this.timeIs = timeIs;
//        this.uri = uri;
//    }
//
//	public String getDate() {
//		return date;
//	}
//
//	public String getTime() {
//		return time;
//	}
//
//	public String getTimeIs() {
//		return timeIs;
//	}
//
//	public String getUri() {
//		return uri;
//	}
//}