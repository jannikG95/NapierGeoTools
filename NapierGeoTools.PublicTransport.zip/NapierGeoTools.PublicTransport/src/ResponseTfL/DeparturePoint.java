package ResponseTfL;

import General.Location;

//public class DeparturePoint extends Location {
//
//	public DeparturePoint(double lat, double lon) {
//		super(lat, lon);
//	}
//	
//}