package ResponseTfL;

import General.Location;

//public class ArrivalPoint extends Location {
//
//	public ArrivalPoint(double lat, double lon) {
//		super(lat, lon);
//
//	}
//	
//
//}